<?php
    $dbhost = "dbase.cs.jhu.edu";
    $dbuser = "22sp_kwu45";
    $dbpass = "JO6UdquBKr";
    $dbname = "22sp_kwu45_db";
?>